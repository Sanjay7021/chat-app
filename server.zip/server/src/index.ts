import { Server } from 'socket.io';
import { createServer } from 'http';
import express from 'express';

// const app = express();


const io = new Server(createServer(), {
  cors: {
    origin: ['http://localhost:5173']
  }
})

let numUsers = 0;

let users: any = [];

io.on('connection', (socket: any) => {
  let addedUser = false;
  console.log(`connect: ${socket.id}`);
  
  // when the client emits 'new message', this listens and executes
  socket.on('new message', (data: any) => {
    // we tell the client to execute 'new message'
    io.emit('new message', {
      username: socket.user.username,
      message: data
    });
  });

  //private chating
  socket.on('private_message', ({ to, message }: { to: string, message: string }) => {
    try {
      const targetUser = users.filter((item: any) => item.username == to);
    console.log('target user',targetUser,to,message);
    if (targetUser) {


      const  newID = targetUser[0].id + socket.user.id
      const newRoomID = newID.split('').sort((a:any,b:any)=> a.localeCompare(b));
      console.log(JSON.stringify(newRoomID))
      

      console.log(targetUser[0].id,newRoomID);
      
      socket.join(JSON.stringify(newRoomID));
      
      socket.to(JSON.stringify(newRoomID)).emit('private_message', {
        from: socket.user.username,
        message
      })
     
    }
    
    } catch (error) {
      console.log(error);
      
    }
  })

  // when the client emits 'add user', this listens and executes
  socket.on('add user', (userDetails: any) => {
    if (addedUser) return;
    console.log(userDetails)
    // we store the username in the socket session for this client
    socket.user = userDetails;
    users.push(userDetails);
    numUsers++;
    addedUser = true;
    socket.emit('login', {
      numUsers: numUsers
    });
    // echo globally (all clients) that a person has connected
    socket.broadcast.emit('user joined', {
      username: socket.user.username,
      numUsers: numUsers
    });
  });

  // when the client emits 'typing', we broadcast it to others
  socket.on('typing', () => {
    socket.broadcast.emit('typing', {
      username: socket.user.username
    });
  });

  // when the client emits 'stop typing', we broadcast it to others
  socket.on('stop typing', () => {
    socket.broadcast.emit('stop typing', {
      username: socket.user.username
    });
  });

  // when the user disconnects.. perform this
  socket.on('disconnect', () => {
    if (addedUser) {
      --numUsers;

      // echo globally that this client has left
      socket.broadcast.emit('user left', {
        username: socket.user.username,
        numUsers: numUsers
      });
    }
  });
});

io.listen(3006);

setInterval(() => {
  io.emit('message', new Date().toISOString());
}, 1000);
