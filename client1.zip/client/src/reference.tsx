// [08:48] Sanjay Dantani
// const express = require('express');
// const http = require('http');
// const socketIo = require('socket.io');
// const bodyParser = require('body-parser');
// const session = require('express-session');
 
// const app = express();
// const server = http.createServer(app);
// const io = socketIo(server);
 
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(express.static('public'));
 
// app.use(session({
//   secret: 'secret-key',
//   resave: false,
//   saveUninitialized: true
// }));
 
// const users = {}; // Store users in memory
 
// app.post('/register', (req, res) => {
//   const { username, password } = req.body;
//   if (users[username]) {
//     return res.status(400).json({ message: 'User already exists' });
//   }
//   users[username] = { username, password, id: Math.random().toString(36).substr(2, 9) };
//   res.status(200).json({ message: 'Registration successful' });
// });
 
// app.post('/login', (req, res) => {
//   const { username, password } = req.body;
//   const user = users[username];
//   if (!user || user.password !== password) {
//     return res.status(400).json({ message: 'Invalid username or password' });
//   }
//   req.session.user = user;
//   res.status(200).json({ message: 'Login successful', user });
// });
 
// io.use((socket, next) => {
//   const sessionID = socket.handshake.query.sessionID;
//   const user = Object.values(users).find(user => user.id === sessionID);
//   if (user) {
//     socket.user = user;
//     next();
//   } else {
//     next(new Error('Authentication error'));
//   }
// });
 
// io.on('connection', (socket) => {
//   console.log(`${socket.user.username} connected`);
 
//   socket.on('private_message', ({ to, message }) => {
//     const targetUser = Object.values(users).find(user => user.username === to);
//     if (targetUser) {
//       io.to(targetUser.id).emit('private_message', { from: socket.user.username, message });
//     }
//   });
 
//   socket.on('disconnect', () => {
//     console.log(`${socket.user.username} disconnected`);
//   });
// });
 
// const PORT = process.env.PORT || 3000;
// server.listen(PORT, () => {
//   console.log(`Server running on port ${PORT}`);
// });






// [08:50] Sanjay Dantani
// import React, { useState, useEffect } from 'react';
// import io from 'socket.io-client';
 
// const socket = io('http://localhost:3000');
 
// const Chat = ({ user }) => {
//   const [message, setMessage] = useState('');
//   const [messages, setMessages] = useState([]);
//   const [recipient, setRecipient] = useState('');
 
//   useEffect(() => {
//     socket.on('private_message', ({ from, message }) => {
//       setMessages((prevMessages) => [...prevMessages, { from, message }]);
//     });
 
//     return () => {
//       socket.off('private_message');
//     };
//   }, []);
 
//   const sendMessage = () => {
//     socket.emit('private_message', { to: recipient, message });
//     setMessages((prevMessages) => [...prevMessages, { from: user.username, message }]);
//     setMessage('');
//   };
 
//   return (
//     <div>
//       <h2>Chat</h2>
//       <div>
//         <input
//           type="text"
//           placeholder="Recipient"
//           value={recipient}
//           onChange={(e) => setRecipient(e.target.value)}
//         />
//       </div>
//       <div className="chat-window">
//         {messages.map((msg, index) => (
//           <div key={index} className="message">
//             <strong>{msg.from}:</strong> {msg.message}
//           </div>
//         ))}
//       </div>
//       <input
//         type="text"
//         value={message}
//         onChange={(e) => setMessage(e.target.value)}
//         placeholder="Type a message..."
//       />
//       <button onClick={sendMessage}>Send</button>
//     </div>
//   );
// };
 
// export default Chat;