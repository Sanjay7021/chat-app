import React, { useState } from 'react';
import {  
  ThemeProvider,
  createTheme, 

} from '@mui/material';

import MUIRichTextEditor from 'mui-rte';
import DoneIcon from '@mui/icons-material/Done'
import { EditorState } from 'draft-js'


const theme = createTheme({
  palette: {
    mode: 'dark', // or 'light' for a light theme
  },
});

const TextEditor = () => {
  const [value, setValue] = useState('');

  const handleValueChange = (value:any) => {
    setValue(value);
  };

  console.log(value);
  return (
    <ThemeProvider theme={theme}>
     <MUIRichTextEditor 
    controls={["my-callback"]}
    customControls={[
        {
            name: "my-callback",
            icon: <DoneIcon />,
            type: "callback",
            onClick: handleValueChange
            
        }
    ]}
/>
    </ThemeProvider>
  );
};

export default TextEditor;