import { useState, useEffect } from 'react';
import './App.css';
import io from 'socket.io-client';
import TextEditor from './component/TextEditor';
// import TextEditor from './component/TextEditor';

const socket: any = io('localhost:3006');

function App() {
  // const defaultTheme = createMuiTheme()
  const [isConnected, setIsConnected] = useState(socket.connected);
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState<any>([]);
  const [sampleMessage, setSampleMessage]: any = useState([]);
  const [participent, setParticipent] = useState('');


  const [private_message, setPrivate_message]: any = useState([]);
  const [recipient, setRecipient]: any = useState('');
  const [pmessage, setPmessage] = useState('');


  let users: { username: null; id: string; }[] = [];

  useEffect(() => {
    socket.on('connect', () => {
      setIsConnected(true);
    });

    socket.on("new message", (data: any) => {
      // console.log("from the backend", data);
      setMessage((prev: string) => { return [...prev, data] });
    })
  }, []);

  useEffect(() => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    socket.on("login", (data: any) => {
      console.log("from the backend login", data);
      setParticipent(() => { return data.numUsers });
    })
  }, [participent])

  useEffect(() => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    socket.on("user joined", (data: any) => {
      console.log('user joined', data)
      setSampleMessage(() => { return [...sampleMessage, `user joined ${data.username}`] })
      setParticipent(() => { return data.numUsers });

    })
  }, [sampleMessage])

  console.log(message);

  const sendMessage = () => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    let data = 'hello'
    
    socket.emit('new message', data);

  }
  const sendMessage1 = () => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    let data = 'Hii'
    // socket.on('new message',()=>{
    socket.emit('new message', data);

    console.log(socket.msg)
    // })
  }

  const addUser = () => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    const id = Math.random().toString(36).substring(2, 9);
    const userDetails = {
      username: user,
      id
    }
    users.push(userDetails);


    console.log('user name ', users);
    socket.emit('add user', userDetails);
    // socket.emit('login',user);
    // window.alert('user added')
  }

  useEffect(() => {
    console.log('callled');
    socket.on('connect', () => {
      setIsConnected(true);
    });
    
    socket.on('private_message', ({ from, message }: { from: string, message: string }) => {
      console.log('fromthe client ',from, message);
      
        setPrivate_message((prev: any) => [...prev, { from, message }])
  
    });

    socket.on('privateMessage',({sender,message}:{sender:any,message:any})=>{
      console.log("another private message",sender,message);
    })
    
    return () => {
      socket.off('private_message');
    };
  }, [])
  console.log("private message coming from the server",private_message);

  const send_private_message = () => {
    socket.on('connect', () => {
      setIsConnected(true);
    });
    console.log("message, user, to ",pmessage,user,recipient)
    socket.emit('private_message', { to: recipient, message: pmessage });
    
    setPrivate_message((prev: any) => [...prev, { from: user, message: pmessage }]);
    setPmessage('');
  }

  return (
    <div className="App">
      <header className="App-header">
        <input type="text" name='neme' onChange={(e: any) => { return setUser(e.target.value) }} />
        <button onClick={addUser}>add user</button>

        <p>Connected: {'' + isConnected}</p>
        <p>participent: {participent}</p>
        <p>{sampleMessage.map((item: any) => {
          return <div>{item}</div>
        })}</p>
        {/* <p>Last message: { lastMessage || '-' }</p> */}
        <button onClick={sendMessage}>Say hello!</button>
        <button onClick={sendMessage1}>Say Hii!</button>

        {
          message && message.map((item: any) => {
            return <div><b>{item.username}</b>: {item.message}</div>
          })
        }
        <br /><br />

        <div style={{ border: '2px solid black', backgroundColor: 'gray', borderRadius: '2px', width: 'auto', height: 'auto' }}>

          <input type="text" placeholder='Enter Reciepient Name to talk' onChange={(e: any) => setRecipient(e.target.value)} />
          <br />


          <div className="chat-window">
            {private_message.map((msg: any, index: number) => (
              <div key={index} className="message">
                <strong>{msg.from}:</strong> {msg.message}
              </div>
            ))}
          </div>
          <br />
          <input type="text" placeholder='enter message' onChange={(e) => setPmessage(e.target.value)} />

          <button onClick={send_private_message}>send</button>
        </div>
    
        <TextEditor />
      </header>

    </div>
  );
}

export default App;
